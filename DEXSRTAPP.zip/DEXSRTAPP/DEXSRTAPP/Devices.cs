﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DEXSRTAPP
{
    public partial class Devices : Form
    {
        public Devices()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btmcerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
